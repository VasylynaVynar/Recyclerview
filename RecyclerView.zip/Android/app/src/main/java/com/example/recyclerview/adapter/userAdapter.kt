package com.example.recyclerview.adapter

class userAdapter {
}