package com.example.recyclerview.model

class userModel (
    val lastName:String,
    val firstName:String
)